<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        \App\Models\User::create(['full_name' => 'John Doe']);
        \App\Models\User::create(['full_name' => 'Jane Smith']);
        \App\Models\User::create(['full_name' => 'Michael Johnson']);

        \App\Models\Activity::create(['user_id' => 1, 'activity_date' => now(), 'points' => 20]);
        \App\Models\Activity::create(['user_id' => 2, 'activity_date' => now(), 'points' => 20]);
        \App\Models\Activity::create(['user_id' => 3, 'activity_date' => now(), 'points' => 20]);
    }
}
