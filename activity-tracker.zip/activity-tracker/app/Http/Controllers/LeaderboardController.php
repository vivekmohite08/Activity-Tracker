<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Activity;
use Illuminate\Http\Request;
use Carbon\Carbon;

class LeaderboardController extends Controller
{
    public function index(Request $request)
    {
        $query = Activity::query();
        if ($request->filter == 'day') {
            $query->whereDate('activity_date', Carbon::today());
        } elseif ($request->filter == 'month') {
            $query->whereMonth('activity_date', Carbon::now()->month);
        } elseif ($request->filter == 'year') {
            $query->whereYear('activity_date', Carbon::now()->year);
        }

        $users = User::withSum('activities', 'points') 
        ->orderBy('total_points', 'desc')
        ->get();

        $rank = 1;
        foreach ($users as $user) {
            if ($user->total_points != 0) {
                $user->rank = $rank;
                $user->save();
            }
            $rank++;
        }

        return view('leaderboard.index', compact('users'));
    }

    public function searchUser(Request $request)
    {
        $user = User::where('id', $request->search)->withSum('activities', 'points')->first();

        if ($user) {
            $users = collect([$user]);
        } else {
            $users = User::withSum('activities', 'points')->orderBy('points', 'desc')->get();
        }

        return view('leaderboard.index', compact('users'));
    }

    public function recalculate()
    {
        $users = User::withSum('activities', 'points')->orderBy('points', 'desc')->get();

        $rank = 1;
        foreach ($users as $user) {
            $user->rank = $rank;
            $user->save();
            $rank++;
        }

        return redirect()->back();
    }

}
